<?php
session_start();
error_reporting(0);
ini_set("default_charset", "UTF-8");
ini_set("date.timezone", "Europe/Warsaw");
header('Content-Type: text/html; charset=utf-8');

require('config.php');
require('pdo.php');

$adminid = (int)$_SESSION['id'];

if (!empty($_SESSION['postidcomment']) && empty($_GET['postid'])) {
	$postid = (int)$_SESSION['postidcomment'];
}else{
	$postid = (int)$_GET['postid'];
}

// redirect if login error
if ($_SESSION['loged'] != 1) {
  header('Location: login.php');
}

// get article title
try {
$db = Conn();	
	$res1 = $db->query("SELECT title FROM article where id = '$postid'");
	if ($res1->rowCount() > 0) {
		$rows = $res1->fetchAll(PDO::FETCH_ASSOC);
	}	
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}

if (isset($_POST['add'])) {
// GET POST DATA
//$_POST['user'] = preg_replace("/[^A-Za-z0-9-_]/",'', $_POST['user']);
$err = 0;

$t = htmlentities($_POST['title'], ENT_QUOTES, 'utf-8');
$c = htmlentities($_POST['editor1'], ENT_QUOTES, 'utf-8');
$userid = (int)$_SESSION['id'];
echo $postid = (int)$_SESSION['postid'];

if (empty($postid)) {
	$postid = 0;
}

if (strlen($t) < 2 || strlen($c) < 2) {	
	$error = "Wypełnij wszystkie pola formularza";
	$err = 1;
}

try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$ip = $_SERVER['REMOTE_ADDR'];		
		$res = $db->exec("INSERT INTO comments(postid,userid,title,content,ip) VALUES($postid,$userid,'$t','$c','$ip')");		
		if ($res == 1) {
			$error = "Komentarz został dodany";		
			$_POST['editor1'] = "";
			$_POST['link'] = "";
			$_POST['title'] = "";
		}else{
			$error = "Coś nie tak.";
		}		
	}
} catch (PDOException $e) {	
	if ($e->getCode() == '23000')
        $error = "Komentarz o takim tytule już istnieje";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}
?>

<?php require('header.php'); ?>
<body>
<?php 
//require('menu.php'); 
?>


<form method="post" action="" style="min-width: 90%">
<label>Dodaj komentarz do artykułu<br> <small> <?php echo $rows[0]['title']; ?> </small></label>

<div style="height: auto; width: 100%; float: left; color: #f23; padding-left: 10px; padding: 5px;"><?php echo $error; ?></div>
		<input type="text"  name="title" maxlength="50" placeholder="Tytuł komentarza" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;" value="<?php if (isset($_POST['title'])) {echo $_POST['title'];}?>">
		<div>
		<textarea placeholder="Treść komentarza" name="editor1" style="min-width: 100%; max-width: 100%; min-height: 90px; box-sizing: border-box; margin-top: 10px;  padding: 5px;"></textarea>
		</div>
	<input type="submit" name="add" value="Dodaj" class="btn animated flipInX" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;">	
<p> <a href="/blog" class="link">Zobacz do bloga</a> <a href="logout.php" class="link-right" style="margin-right: 0px;">Wyloguj się</a></p>
</form>

<?php require('footer.php'); ?>
</body>
</html>
