/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
// Enable local "newplugin" plugin from plugins/newplugin folder.
CKEDITOR.plugins.addExternal( 'youtube', 'plugins/youtube/', 'plugin.js' );
CKEDITOR.plugins.addExternal( 'videodetector', 'plugins/videodetector/', 'plugin.js' );
//CKEDITOR.plugins.addExternal( 'imagebrowser', 'plugins/imagebrowser/', 'plugin.js' );
//CKEDITOR.plugins.addExternal( 'widget', 'plugins/widget/', 'plugin.js' );
//CKEDITOR.plugins.addExternal( 'dialog', 'plugins/dialog/', 'plugin.js' );
//CKEDITOR.plugins.addExternal( 'codesnippet', 'plugins/codesnippet/', 'plugin.js' );
//CKEDITOR.plugins.addExternal( 'codemirror', 'plugins/codemirror/', 'plugin.js' );

CKEDITOR.editorConfig = function( config ) {
	config.height = 500;
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
	//config.extraPlugins = 'youtube,videodetector,widget,dialog,codesnippet';
	config.extraPlugins = 'youtube,videodetector';
	config.removeDialogTabs = 'image:advanced';
	config.removePlugins = 'flash';
	// relative path for smiles
	//config.smiley_path = 'ckeditor/plugins/smiley/images/';
	// Allow javascript in ck editor
	/*
	config.allowedContent = {
        script: true,
        $1: {
            // This will set the default set of elements
            elements: CKEDITOR.dtd,
            attributes: true,
            styles: true,
            classes: true
        }
    };
    */
};
