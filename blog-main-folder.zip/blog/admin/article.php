<?php
require('session.php');

if ($_SESSION['loged'] != 1) {
  header('Location: login.php');
}

$adminid = (int)$_SESSION['id'];

if (isset($_POST['add'])) {
// GET POST DATA
//$_POST['user'] = preg_replace("/[^A-Za-z0-9-_]/",'', $_POST['user']);
$err = 0;
$l = htmlentities($_POST['link'], ENT_QUOTES, 'utf-8');
$t = htmlentities($_POST['title'], ENT_QUOTES, 'utf-8');
$c = htmlentities($_POST['editor1'], ENT_QUOTES, 'utf-8');
$tag = htmlentities($_POST['tag'], ENT_QUOTES, 'utf-8');
$type = (int)$_POST['type'];
$cid = (int)$_POST['catid'];
$gid = (int)$_POST['galleryid'];
$uid = (int)$_SESSION['id'];

if (strlen($t) < 2 || strlen($c) < 2) {	
	$error = "Wypełnij wszystkie pola formularza";
	$err = 1;
}

// INSERT TO MYSQL
// INSERT INTO user(user) VALUES (N'శ్రీనివాస్ తామాడా'), (N'新概念英语第');
try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$ip = $_SERVER['REMOTE_ADDR'];		
		$res = $db->exec("INSERT INTO article(userid,categoryid,title,media,content,tag,type,galleryid,ip) VALUES($uid,$cid,'$t','$l','$c','$tag',$type,$gid,'$ip')");		
		if ($res == 1) {
			$error = "Artykuł został dodany";		
			$_POST['editor1'] = "";
			$_POST['link'] = "";
			$_POST['title'] = "";
		}		
	}
} catch (PDOException $e) {	
	if ($e->getCode() == '23000')
        $error = "Artykuł o takim tytule już istnieje";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}

// del category
if (isset($_POST['usun'])) {
$err = 0;
$cat = (int)$_POST['usunid'];

try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$res = $db->exec("UPDATE article SET active = '0' WHERE id = $cat");		
		if ($res == 1) {
			$error = "Artykuł został usunięty";		
		}		
	}
} catch (PDOException $e) {	
	if ($e->getCode() == '23000')
        $error = "Kategoria już nie istnieje";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}


if (isset($_POST['update'])) {
// GET POST DATA
//$_POST['user'] = preg_replace("/[^A-Za-z0-9-_]/",'', $_POST['user']);
$err = 0;
$u = htmlentities($_POST['user'], ENT_QUOTES, 'utf-8');
$e = htmlentities($_POST['email'], ENT_QUOTES, 'utf-8');
$cid = (int)$_POST['dd'];

if (strlen($u) < 2 || strlen($e) < 2) {	
	$error = "Wypełnij wszystkie pola formularza";
	$err = 1;
}

// INSERT TO MYSQL
// INSERT INTO user(user) VALUES (N'శ్రీనివాస్ తామాడా'), (N'新概念英语第');
try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$ip = $_SERVER['REMOTE_ADDR'];				
		$res = $db->exec("UPDATE category SET title = '$u', about = '$e', ip = '$ip' WHERE id = $cid");		
		if ($res == 1) {
			$error = "Kategoria została zaktualizowana";		
		}		
	}
} catch (PDOException $e) {	
	echo $e->getMessage();
	if ($e->getCode() == '23000')
        $error = "Kategoria już istnieje";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}

// select category
try {
$db = Conn();	
	$res1 = $db->query("SELECT * FROM category where active = '1'");
	if ($res1->rowCount() > 0) {
		$rows = $res1->fetchAll(PDO::FETCH_ASSOC);
	}else{
		$error = "Coś poszło nie tak!!!";
	}	
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}

?>

<?php require('header.php'); ?>
<body>
<?php 
require('menu.php'); 

try {
$db = Conn();	
	$res1 = $db->query("SELECT * FROM gallery where active = '1' AND adminid = '$adminid'");
	if ($res1->rowCount() > 0) {
		$rows1 = $res1->fetchAll(PDO::FETCH_ASSOC);
	}
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}
?>


<form method="post" action="" style="min-width: 90%">
<label>Dodaj artykuł</label>
<div style="height: auto; width: 100%; float: left; color: #f23; padding-left: 10px; padding: 5px;"><?php echo $error; ?></div>
		<input type="text" name="link" maxlength="250" placeholder="Link do zdjecia (Zdjecia) lub link do filmu youtube" autocomplete="false" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;" value="<?php if (isset($_POST['link'])) {echo $_POST['link'];}?>">
		<input type="text" name="title" maxlength="250" placeholder="Tytuł" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;" value="<?php if (isset($_POST['title'])) {echo $_POST['title'];}?>">
		<input type="text" name="tag" maxlength="250" placeholder="Tagi i hashtagi" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;" value="<?php if (isset($_POST['tag'])) {echo $_POST['tag'];}?>">
		<div>
		<textarea name="editor1" style="min-width: 95%; max-width: 95%; min-height: 90px; box-sizing: border-box; margin-top: 10px; padding: 5%"><?php if (isset($_POST['editor1'])) {echo $_POST['editor1'];}?></textarea>
		</div>
		<ul class="dofb">
		<select name="type" style="min-width: 100%; box-sizing: border-box; margin-top: 10px;">			
			<?php 
				echo '<option value="0">Wybierz typ</option>';			
				echo '<option value="0">Tekstowy</option>';
				echo '<option value="1">Zdjecie</option>';
				echo '<option value="2">Wideo</option>';
			?>
		</select>	
		<select name="catid" style="min-width: 100%; box-sizing: border-box; margin-top: 10px;">			
			<?php
			echo '<option value="0">Wybierz kategorię</option>'; 			
			foreach ($rows as $row) {
				echo '<option value="'.$row['id'].'">'.$row['title'].' ('.$row['about'].')</option>';
			}
			?>
		</select>	
		</ul>		
		<select name="galleryid" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;">			
			<?php 
			echo '<option value="0">Dodaj galerię (niewymagane)</option>';
			foreach ($rows1 as $row) {
				echo '<option value="'.$row['id'].'">('.$row['id'].') '.$row['name'].' ('.$row['about'].')</option>';
			}
			?>
		</select>
	<input type="submit" name="add" value="Dodaj" class="btn animated flipInX" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;">	
</form>

<script src="ckeditor/ckeditor.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script>        
$(function(){
    $("html").on( "click", function() {
        var data = CKEDITOR.instances.editor1.getData();              
    });
});

CKEDITOR.replace( 'editor1' , {
	//browse button
    //filebrowserBrowseUrl: 'browse.php?type=Files',
    filebrowserUploadUrl: 'uploadeditor.php?type=Files',
    removeDialogTabs : 'image:advanced'
});     
</script>


<div class="lista" style="background: #fff;">
	<?php
	
	function pagine($table= 'article', $perpage = 25){
		if(empty($_GET['page'])){$page = 1;}else{$page = (int)$_GET['page'];}
		$pagenext = $page +1;
		$pageprev = $page -1;
		if ($pageprev < 0){$pageprev = 1;}
		$offset = ($page - 1) * $perpage;
		global $adminid;
		$sql = "SELECT * FROM ".$table." WHERE active != '0' AND userid = '".$adminid."' ORDER BY id DESC LIMIT " . $offset . "," . $perpage;
		global $db; // get pdo connection Conn()
		$st = $db->query($sql);
		$row = $st->fetchAll(PDO::FETCH_ASSOC);

		echo '<p class="pagine"><a class="pagelink" href="?page='.$pageprev.'"> Poprzednia</a>';
		echo '<a class="pagelink"> '.$page.' </a>';
		echo '<a class="pagelink" href="?page='.$pagenext.'"> Nastepna</a></p>';
		return $row;
	}

	
	//$st = $db->query("SELECT * FROM campaning WHERE adminid = '0' AND active = '1'");
	//$rows = $st->fetchALL(PDO::FETCH_ASSOC);

	echo '<div class="tg-wrap" style="background: #fff">';
	$ro = pagine();

	echo '<table id="tg-RsPwC" class="tg">
	  <tr style="background: #eee; color: #444">    <th class="tg1">ID</th>    <th class="tg1">Numer galerii/Link</th> <th class="tg1">Numer galerii/Link</th>  <th class="tg1">Tagi</th>  <th class="tg1">Data dodania</th>    <th class="tg1">Ustawienia</th>  </tr>';	
		foreach ($ro as $v) {
			$host = $_SERVER['HTTP_HOST']."/";
			$id = $v['id'];
			$title = $v['title'];
			$media = $v['media'];
			$tag = $v['tag'];
			if ($title  != "") {
			  echo '<tr>    <td class="tg1">'.$v['id'].'</td>    <td class="tg1"><a class="gallerylink" target="_blank" title="Pokaż galerię" href="/article/'.$id.'"> '.$title.'</a> </td> <td class="tg1" style="text-align: center;">'.$media.'</td>  <td class="tg1" style="text-align: center;">'.$tag.'</td> <td class="tg1">'.$v['time'].'</td>    <td class="tg1">
					<a class="abtn" href="?id='.$v['id'].'" title="Usuń"> <i class="fa fa-trash"></i></a> 
					<a class="abtn" href="articleedit.php?id='.$v['id'].'" title="Edytuj post"> <i class="fa fa-edit"></i></a> 
			  </td>  </tr>';
			}		
		}
		echo 	'</table></div>';

	?>
</div>

<?php require('footer.php'); ?>
</body>
</html>
