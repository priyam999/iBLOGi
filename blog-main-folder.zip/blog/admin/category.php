<?php
require('session.php');

if ($_SESSION['loged'] != 1) {
  header('Location: login.php');
}

$admin = (int)$_SESSION['vip'];

if (isset($_POST['add']) && $admin == 0) {
// GET POST DATA
//$_POST['user'] = preg_replace("/[^A-Za-z0-9-_]/",'', $_POST['user']);
$err = 0;
$u = htmlentities($_POST['user'], ENT_QUOTES, 'utf-8');
$e = htmlentities($_POST['email'], ENT_QUOTES, 'utf-8');
$dd = (int)$_POST['dd'];

if (strlen($u) < 2 || strlen($e) < 2) {	
	$error = "Wypełnij wszystkie pola formularza";
	$err = 1;
}

// INSERT TO MYSQL
// INSERT INTO user(user) VALUES (N'శ్రీనివాస్ తామాడా'), (N'新概念英语第');
try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$ip = $_SERVER['REMOTE_ADDR'];		
		$res = $db->exec("INSERT INTO category(subid,title,about,ip) VALUES($dd,'$u','$e','$ip')");		
		if ($res == 1) {
			$error = "Kategoria została dodana";		
		}		
	}
} catch (PDOException $e) {	
	if ($e->getCode() == '23000')
        $error = "Kategoria już istnieje";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}

// del category
if (isset($_POST['usun']) && $admin == 0) {
$err = 0;
$cat = (int)$_POST['usunid'];

try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$res = $db->exec("UPDATE category SET active = '0' WHERE id = $cat");		
		if ($res == 1) {
			$error = "Kategoria została usunięta";		
		}		
	}
} catch (PDOException $e) {	
	if ($e->getCode() == '23000')
        $error = "Kategoria już nie istnieje";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}

// del category
if (isset($_POST['on']) && $admin == 0) {
$err = 0;
$cat = (int)$_POST['onid'];

try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$res = $db->exec("UPDATE category SET active = '1' WHERE id = $cat");		
		if ($res == 1) {
			$error = "Kategoria została włączona";		
		}		
	}
} catch (PDOException $e) {	
	if ($e->getCode() == '23000')
        $error = "Kategoria już nie istnieje";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}


if (isset($_POST['update']) && $admin == 0) {
// GET POST DATA
//$_POST['user'] = preg_replace("/[^A-Za-z0-9-_]/",'', $_POST['user']);
$err = 0;
$u = htmlentities($_POST['user'], ENT_QUOTES, 'utf-8');
$e = htmlentities($_POST['email'], ENT_QUOTES, 'utf-8');
$cid = (int)$_POST['dd'];

if (strlen($u) < 2 || strlen($e) < 2) {	
	$error = "Wypełnij wszystkie pola formularza";
	$err = 1;
}

// INSERT TO MYSQL
// INSERT INTO user(user) VALUES (N'శ్రీనివాస్ తామాడా'), (N'新概念英语第');
try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$ip = $_SERVER['REMOTE_ADDR'];				
		$res = $db->exec("UPDATE category SET title = '$u', about = '$e', ip = '$ip' WHERE id = $cid");		
		if ($res == 1) {
			$error = "Kategoria została zaktualizowana";		
		}		
	}
} catch (PDOException $e) {	
	echo $e->getMessage();
	if ($e->getCode() == '23000')
        $error = "Kategoria już istnieje";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}

// select category
try {
$db = Conn();	
	$res1 = $db->query("SELECT * FROM category where active = '1'");
	if ($res1->rowCount() > 0) {
		$rows = $res1->fetchAll(PDO::FETCH_ASSOC);
	}
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}

?>

<?php require('header.php'); ?>
<body>
<?php 
require('menu.php'); 
?>


<form method="post" action="">
<label>Dodaj kategorię</label>
<div style="height: auto; width: 100%; float: left; color: #f23; padding-left: 10px; padding: 5px;"><?php echo $error; ?></div>
	<input type="text" name="user" maxlength="50" placeholder="Nazwa kategorii" >
	<input type="text" name="email" maxlength="200" placeholder="Opis kategorii" autocomplete="false">
	<ul class="dofb">
		<select name="dd" style="min-width: 98%; box-sizing: border-box;">			
			<?php 
			echo '<option value="0">Kategoria główna</option>';
			foreach ($rows as $row) {
				echo '<option value="'.$row['id'].'">'.$row['title'].' ('.$row['about'].')</option>';
			}
			?>
		</select>
	</ul>
	<input type="submit" name="add" value="Dodaj" class="btn animated flipInX">	
</form>

<div>
<form method="post" action="">
<label>Aktualizuj kategorię</label>
	<input type="text" name="user" maxlength="50" placeholder="Nowa nazwa kategorii">
	<input type="text" name="email" maxlength="200" placeholder="Nowy opis kategorii" autocomplete="false">
	<ul class="dofb">
		<select name="dd" style="min-width: 98%; box-sizing: border-box;">			
			<?php 
			echo '<option value="0">Wybierz</option>';
			foreach ($rows as $row) {
				echo '<option value="'.$row['id'].'">'.$row['title'].' ('.$row['about'].')</option>';
			}
			?>
		</select>
	</ul>
	<input type="submit" name="update" value="Aktualizuj" class="btn animated flipInX">	
</form>

<form method="post" action="">
<label>Usuń kategorię</label>
<select name="usunid" method="post" action="" style="min-width: 98%;">	
<?php 
echo '<option value="0">Wybierz kategorie</option>';
foreach ($rows as $row) {
	echo '<option value="'.$row['id'].'">'.$row['title'].' ('.$row['about'].')</option>';
}
?>
</select>	
<input type="submit" name="usun" value="Usuń" class="btn animated flipInX">
</form>

<form method="post" action="">
<label>Włącz kategorię</label>
<select name="onid" method="post" action="" style="min-width: 98%;">	
<?php 
// select category
try {
$db = Conn();	
	$res1 = $db->query("SELECT * FROM category where active = '0'");
	if ($res1->rowCount() > 0) {
		$rows = $res1->fetchAll(PDO::FETCH_ASSOC);
	}
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}

echo '<option value="0">Wybierz kategorie</option>';
foreach ($rows as $row) {
	echo '<option value="'.$row['id'].'">'.$row['title'].' ('.$row['about'].')</option>';
}
?>
</select>	
<input type="submit" name="on" value="Włącz" class="btn animated flipInX">
</form>
</div>


</body>
</html>
