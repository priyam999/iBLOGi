<?php
require('session.php');

if ($_SESSION['loged'] != 1) {
  header('Location: login.php');
}

$adminid = (int)$_SESSION['id'];
$articleid = (int)$_GET['id'];

try {
$db = Conn();	
	$res1 = $db->query("SELECT * FROM article where active = '1' AND userid = '$adminid' AND id = $articleid");
	if ($res1->rowCount() > 0) {
		$rows11 = $res1->fetchAll(PDO::FETCH_ASSOC);		
	}else{
		$error = "Coś poszło nie tak!!!";
	}	
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}

if (isset($_POST['add'])) {
// GET POST DATA
//$_POST['user'] = preg_replace("/[^A-Za-z0-9-_]/",'', $_POST['user']);
$err = 0;
$l = htmlentities($_POST['link'], ENT_QUOTES, 'utf-8');
$t = htmlentities($_POST['title'], ENT_QUOTES, 'utf-8');
$c = htmlentities($_POST['editor1'], ENT_QUOTES, 'utf-8');
$tag = htmlentities($_POST['tag'], ENT_QUOTES, 'utf-8');
$type = (int)$_POST['type'];
$cid = (int)$_POST['catid'];
$gid = (int)$_POST['galleryid'];
$uid = (int)$_SESSION['id'];
$aid =  $rows11[0]['id'];

if (strlen($t) < 2 || strlen($c) < 2) {	
	$error = "Wypełnij wszystkie pola formularza";
	$err = 1;
}

try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$ip = $_SERVER['REMOTE_ADDR'];		
		$sql = "UPDATE article SET categoryid = $cid, title = '$t', media = '$l', content = '$c', tag = '$tag', type = $type, galleryid = $gid, ip = '$ip' WHERE id = $aid AND userid = $uid";
		//echo $sql = "UPDATE article SET title = '$t', media = '$l', content = '$c' WHERE id = $aid AND userid = $uid";
		$res = $db->exec($sql);

		if ($res == 1) {
			$error = "Artykuł został zaktualizowany";		
			$_POST['editor1'] = "";
			$_POST['link'] = "";
			$_POST['title'] = "";
		}		
	}
} catch (PDOException $e) {	
	if ($e->getCode() == '23000')
        $error = "Artykuł o takim tytule już istnieje";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}

// select category
try {
$db = Conn();	
	$res1 = $db->query("SELECT * FROM category where active = '1'");
	if ($res1->rowCount() > 0) {
		$rows = $res1->fetchAll(PDO::FETCH_ASSOC);
	}else{
		$error = "Coś poszło nie tak!!!";
	}	
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}

?>

<?php require('header.php'); ?>
<body>
<?php 
require('menu.php'); 

try {
$db = Conn();	
	$res1 = $db->query("SELECT * FROM gallery where active = '1' AND adminid = '$adminid'");
	if ($res1->rowCount() > 0) {
		$rows1 = $res1->fetchAll(PDO::FETCH_ASSOC);
	}	
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}

?>



<form method="post" action="" style="min-width: 90%">
<label>Edytuj artykuł</label>
<div style="height: auto; width: 100%; float: left; color: #f23; padding-left: 10px; padding: 5px;"><?php echo $error; ?></div>
		<input type="text" name="link" maxlength="200" placeholder="Link do zdjecia (Zdjecia) lub link do filmu youtube" autocomplete="false" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;" value="<?php if (isset($_POST['link'])) {echo $_POST['link'];}else{echo $rows11[0]['media'];}?>">
		<input type="text" name="title" maxlength="50" placeholder="Tytuł" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;" value="<?php if (isset($_POST['title'])) {echo $_POST['title'];}else{echo $rows11[0]['title'];}?>">
		<input type="text" name="tag" maxlength="250" placeholder="Tagi i hashtagi" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;" value="<?php if (isset($_POST['tag'])) {echo $_POST['tag'];}else{echo $rows11[0]['tag'];} ?>">
		<div>
		<textarea name="editor1" style="min-width: 95%; max-width: 95%; min-height: 90px; box-sizing: border-box; margin-top: 10px; padding: 5%"><?php if (isset($_POST['editor1'])) {echo $_POST['editor1'];}else{echo $rows11[0]['content'];}?></textarea>
		</div>
		<ul class="dofb">
		<select name="type" style="min-width: 100%; box-sizing: border-box; margin-top: 10px;">			
			<?php 
				if ($row['id'] == $rows11[0]['categoryid']) {
					$show = 'selected';
				}		
				echo '<option value="1">Zdjecie</option>';
				echo '<option value="2">Wideo</option>';
				echo '<option value="0">Tekstowy</option>';
			?>
		</select>	
		<select name="catid" style="min-width: 100%; box-sizing: border-box; margin-top: 10px;">			
			<?php
			$show = "";
			foreach ($rows as $row) {
				if ($row['id'] == $rows11[0]['categoryid']) {
					$show = 'selected';
				}
				echo '<option '.$show.' value="'.$row['id'].'">'.$row['title'].' ('.$row['about'].')</option>';	
				$show = '';			
			}
			?>
		</select>	
		</ul>		
		<select name="galleryid" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;">			
			<?php 			
			$show ="";
			echo '<option value="0">Dodaj galerię (niewymagane)</option>';
			foreach ($rows1 as $row) {
				if ($row['id'] == $rows11[0]['galleryid'] && $rows11[0]['galleryid'] != 0) {
					$show = 'selected';
				}				
				echo '<option '.$show.' value="'.$row['id'].'">('.$row['id'].') '.$row['name'].' ('.$row['about'].')</option>';		
				$show = '';		
			}
			?>
		</select>
	<input type="submit" name="add" value="Aktualizuj artykuł" class="btn animated flipInX" style="margin-left: 0px; min-width: 100%; box-sizing: border-box; margin-top: 10px;">	
</form>

<script src="ckeditor/ckeditor.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script>        
$(function(){
    $("html").on( "click", function() {
        var data = CKEDITOR.instances.editor1.getData();              
    });
});

CKEDITOR.replace( 'editor1' , {
	//browse button
    //filebrowserBrowseUrl: 'browse.php?type=Files',
    filebrowserUploadUrl: 'uploadeditor.php?type=Files',
    removeDialogTabs : 'image:advanced'
});     
</script>


<?php require('footer.php'); ?>
</body>
</html>
