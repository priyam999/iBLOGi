<?php
require('session.php');

if ($_SESSION['loged'] != 1) {
  header('Location: login.php');
}

$admin = (int)$_SESSION['vip'];
//echo "<pre>";
//print_r($_SERVER);


if (isset($_POST['add']) && $admin == 0) {
// GET POST DATA
//$_POST['user'] = preg_replace("/[^A-Za-z0-9-_]/",'', $_POST['user']);
$err = 0;
$tt = htmlentities($_POST['title'], ENT_QUOTES, 'utf-8');
$dd = (int)$_POST['dd'];
$pp = (int)$_POST['panel'];

//short link
//$ll = 'category/'.$dd;
// long link
$ll = '//'.$_SERVER['HTTP_HOST'].'/category/'.$dd;

if (strlen($tt) < 2) {	
	$error = "Wypełnij wszystkie pola formularza";
	$err = 1;
}

try { 
$db = Conn();
	if ($err == 0) {		
		$ip = $_SERVER['REMOTE_ADDR'];		
		$res = $db->exec("INSERT INTO menu(menuid,catid,title,link) VALUES($pp,$dd,'$tt','$ll')");		
		if ($res == 1) {
			$error = "Kategoria została dodana do menu";		
		}		
	}
} catch (PDOException $e) {	
	if ($e->getCode() == '23000')
        $error = "Kategoria już istnieje w menu";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}


if (isset($_POST['addlink']) && $admin == 0) {
// GET POST DATA
//$_POST['user'] = preg_replace("/[^A-Za-z0-9-_]/",'', $_POST['user']);
$err = 0;
$tt = htmlentities($_POST['title'], ENT_QUOTES, 'utf-8');
$ll = htmlentities($_POST['link'], ENT_QUOTES, 'utf-8');
$pp = (int)$_POST['panel'];

if (strlen($tt) < 2) {	
	$error = "Wypełnij wszystkie pola formularza";
	$err = 1;
}

try { 
$db = Conn();
	if ($err == 0) {		
		$ip = $_SERVER['REMOTE_ADDR'];		
		$res = $db->exec("INSERT INTO menu(menuid,title,link,type) VALUES($pp,'$tt','$ll', '1')");		
		if ($res == 1) {
			$error = "Odnośnik dodany do menu";		
		}		
	}
} catch (PDOException $e) {	
	if ($e->getCode() == '23000')
        $error = "Odnośnik lub strona już istnieje w menu";
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}

// del category
if (isset($_POST['usun']) && $admin == 0) {
$err = 0;
$cat = (int)$_POST['usunid'];

try { 
//CONNECT
$db = Conn();
	if ($err == 0) {		
		$res = $db->exec("DELETE from menu WHERE id = $cat");		
		if ($res == 1) {
			$error = "Link został usunięty";		
		}		
	}
} catch (PDOException $e) {	
    if ($e->getCode() == '2A000')
        echo "Syntax Error: ".$e->getMessage();
} 
}


// select category
try {
$db = Conn();	
	$res1 = $db->query("SELECT * FROM category where active = '1'");
	if ($res1->rowCount() > 0) {
		$rows = $res1->fetchAll(PDO::FETCH_ASSOC);
	}
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}

// select menu
try {
$db = Conn();	
	$res1 = $db->query("SELECT * FROM menu");
	if ($res1->rowCount() > 0) {
		$rows1 = $res1->fetchAll(PDO::FETCH_ASSOC);
	}
} catch (Exception $e) {
	echo "Syntax Error: ".$e->getMessage();
}
?>

<?php require('header.php'); ?>
<body>
<?php 
require('menu.php'); 
?>


<form method="post" action="">
<label>Dodaj kategorię do menu</label>
<div style="height: auto; width: 100%; float: left; color: #f23; padding-left: 10px; padding: 5px;"><?php echo $error; ?></div>
	<input type="text" name="title" maxlength="250" placeholder="Nazwa w menu" autocomplete="false">
	<ul class="dofb">
		<select name="dd" style="min-width: 98%; box-sizing: border-box; margin-top: 10px;">			
			<?php 
			foreach ($rows as $row) {
				echo '<option value="'.$row['id'].'">'.$row['title'].' ('.$row['about'].')</option>';
			}
			?>
		</select>
			<select name="panel" style="min-width: 98%; box-sizing: border-box; margin-top: 10px">			
			<?php 			
			for($i = 0; $i <= 30; $i++) {
				echo '<option value="'.$i.'"> Menu '.$i.'</option>';
			}
			?>
		</select>
	</ul>
	<input type="submit" name="add" value="Dodaj" class="btn animated flipInX">	
</form>


<form method="post" action="">
<label>Dodaj link do menu</label>
<div style="height: auto; width: 100%; float: left; color: #f23; padding-left: 10px; padding: 5px;"><?php echo $error; ?></div>
	<input type="text" name="title" maxlength="250" placeholder="Nazwa w menu" autocomplete="false">
	<input type="text" name="link" maxlength="250" placeholder="Link, stronę, galerię ( page/one lub http://domena/folder/plik.php )" autocomplete="false">
	<ul class="dofb">
			<select name="panel" style="min-width: 98%; box-sizing: border-box; margin-top: 10px">			
			<?php 			
			for($i = 0; $i <= 30; $i++) {
				echo '<option value="'.$i.'"> Menu '.$i.'</option>';
			}
			?>
		</select>
	</ul>
	<input type="submit" name="addlink" value="Dodaj" class="btn animated flipInX">	
</form>

<form method="post" action="">
<label>Usuń z menu</label>
<select name="usunid" method="post" action="" style="min-width: 98%;">	
<?php 
echo '<option value="0">Wybierz kategorie</option>';
foreach ($rows1 as $row) {
	echo '<option value="'.$row['id'].'">Menu '.$row['menuid'].' | '.$row['title'].' | '.$row['link'].'</option>';
}
?>
</select>	
<input type="submit" name="usun" value="Usuń" class="btn animated flipInX">
</form>


</body>
</html>
