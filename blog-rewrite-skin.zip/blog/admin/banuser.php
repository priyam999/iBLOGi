<?php
if ($_SESSION['vip'] > 0) {
	//echo $_SESSION['vip'];
	echo '<p>Tylko administrator ma dostęp do tej zawartości.</p>';	
	die();
}
?>